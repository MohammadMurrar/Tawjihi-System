package application;

public interface Operation<E> {

	// interface for the methods
	void insertSorted(int seatNumber, String branch, double average);
	void delete(int seatNumber);
	String search(int seatNumber);
	String topTen(); 
	String mean(); 
	String mode();
	String numberAndPercentage(double sGrade); 
}
