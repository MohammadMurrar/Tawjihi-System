package application;

public class Node<E extends  Comparable<E>> { 
	//Node Class with its attributes ,constructor ,setter & getter and toString method  
	private int seatNumber;
	private String branch;
	private double average;
	private Node <E> next;
	
	
	public Node(int seatNumber, String branch, double average) {
		this.seatNumber = seatNumber;
		this.branch = branch;
		this.average = average;
	}
	public int getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public double getAverage() {
		return average;
	}
	public void setAverage(double average) {
		this.average = average;
	}
	public Node<E> getNext() {
		return next;
	}
	public void setNext(Node<E> next) {
		this.next = next;
	}
	@Override
	public String toString() {
		return " [seatNumber =" + seatNumber + ", branch =" + branch + ", average =" + average + "]\n";
	}
}
