package application;

import java.util.Iterator;

public class LinkedList<E extends Comparable<E>> implements Operation<E> {
	
	private Node <E> head;

	//Method to insert new nodes sorted according to the seat number to the list
	@Override
	public void insertSorted(int seatNumber, String branch, double average) {
		Node <E> node = new Node(seatNumber,branch,average); //create new node
		if(head == null) { // case 0 : insert at empty List
			head = node;
		}
		else {
			// create two pointer to check the nodes 
			Node <E> curr = head;
			Node <E> prev = null;
			while(curr != null && curr.getAverage() > average) { 
				/* loop that make the current check the nodes and 
				 * put the node we want to insert it in the right place
				*/
				prev = curr;
				curr = curr.getNext();
			}   
			if(prev == null) { //case 1 : insert at the head
				node.setNext(head);
				head = node;
			}
			else { //case 2 & 3 : insert the node between or at the end of nodes
				node.setNext(curr);
				prev.setNext(node);
			}
		}
	}

	@Override
	public void delete(int seatNumber) {//Method to delete nodes from the Linked list
		if(head == null) { // case 0 : the head is null so there's no list
			System.out.println("It's Empty LinkedList");
		}
		if(head.getSeatNumber() == seatNumber) { 
			// case 1 : delete head's node   
			head = head.getNext();
			System.out.println("Node has deleted");
		}
		else {
			/* Third and last cases :
			 * create two pointer as we do in insert method, almost for the same purpose
			 * with an additional condition to stop the current 
			 * with out checks all the nodes 
			*/ 
			Node <E> curr = head;
			Node <E> prev = null;
			while(curr != null) {
				if(curr.getSeatNumber() == seatNumber)  //case 2 & 3 : delete the node between or at the end of nodes
					prev.setNext(curr.getNext());
				
				prev = curr;
				curr = curr.getNext();				
			}
		}
	}
	
	//Method for searching about nodes
	@Override
	public String search(int seatNumber) {
		if (head == null) { //case 0 : Empty list
			return null;
		}
		Node<E> curr = head;
		while(curr != null && curr.getNext() != null ) { //case 1 : searching  
			if(curr.getSeatNumber() == seatNumber) { 
				return curr.toString() ;
				}
			curr = curr.getNext();
		}
		return "Record Not found";
	}
	
	
	@Override
	public String topTen() {
		String str = "";
		Node<E> curr = head;
		Node<E> prev = null;
		int j = 0;
		while (curr != null && curr.getNext() != null &&  j < 10) {
			str += curr.toString();
			prev = curr;
			curr = curr.getNext();
			while(prev.getAverage()==curr.getAverage()) {
				str += curr.toString();
				prev = curr;
				curr = curr.getNext();
				}
			j++;
			}
		return " The Top 10 students in the list are : \n"+str;
	}

	
	
	@Override
	public String mean() { // Method to calculate the mean with basic operations
		int countS = 0, countL = 0 ;
		double sumS = 0, sumL = 0;
		Node<E> curr = head;
		while(curr != null) {
			if(curr.getBranch().compareTo("Scientific")==0){
				sumS+=curr.getAverage();
				countS++;
			}
			if(curr.getBranch().compareTo("Literary")==0){
				sumL+=curr.getAverage();
				countL++;
			}
			curr = curr.getNext();
		}
		return "The mean of Scientific is : " +(sumS/countS)+"%\n\n" +
				"The mean of Literary is : " +(sumL/countL)+"%";
	}

	@Override
	public String mode() {
		Node<E> curr = head;
		Node<E> prev = null;
		double mode = 0;
		int counter = 0, maxCounter = 0;
		while (curr != null) {
			if(curr.getNext()==null) {
				break;
			}
			prev = curr;
			curr = curr.getNext();
			counter = 1;
			if(curr.getAverage() == prev.getAverage()) {
				counter++;
				prev = curr;
				curr = curr.getNext();
			}
			if (counter > maxCounter) {
				maxCounter = counter;
				 mode = curr.getAverage();
			}
		}
		return "The common average is : " + mode;
	}
		
	@Override
	public String numberAndPercentage(double sGrade) {/*Method to calculate number and percentage of students,
		 *  whom grade above or equal a specific grade */
		int iS = 0; //For students whom above above or equal a specific grade in Scientific 
		int iL = 0; //For students whom above above or equal a specific grade in Literary
		double count = 0; //For all students in the list to calculate the %
		Node<E> curr = head;
		while(curr != null) {
			if(curr.getBranch().compareTo("Scientific") == 0 && curr.getAverage() >= sGrade) {
				iS++;
			}
			if(curr.getBranch().compareTo("Literary") == 0 && curr.getAverage() >= sGrade) {
				iL++;
			}
			count++;
			curr = curr.getNext();
		}
		double percentageS = ((iS/count)*100);
		double percentageL = ((iL/count)*100);
		return "The Number of Scientific Student "+iS+" and the Percentage is " +percentageS+"%\n\n" + 
		"The Number of Literary Student "+iL+" and the Percentage is " +percentageL+"%\n\n";
	}

	public String scientificPrint() {  //Print Scientific students from the list
		String s = "";
		Node <E> curr = head;
		while(curr != null) {
			if(curr.getBranch().equals("Scientific")) {
			s += curr.toString();
			}
			curr = curr.getNext();
		}
		return s + " ";
		
	}
	
	public String LiteraryPrint() { //Print Literary students from the list
		String s = "";
		Node <E> curr = head;
		while(curr != null) {
			if(curr.getBranch().equals("Literary")) {
			s += curr.toString();
			}
			curr = curr.getNext();
		}
		return s + " ";
		
	}
	
	@Override
	public String toString() { //Print full list
		String s = "";
		Node <E> curr = head;
		while(curr != null) {
			s += curr.toString();
			curr = curr.getNext();
		}
		return s + " ";
	}


	


}
