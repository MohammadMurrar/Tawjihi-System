package application;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;


public class Main extends Application {

	 static LinkedList <String> westBankList = new LinkedList<>(); 
	 static LinkedList <String> gazaList = new LinkedList<>();
	 static int seatNumber;
	 static String branch;
	 static double avg;
	@Override
	public void start(Stage primaryStage) {
		
		// create GridPane and modify its attributes
		GridPane gp = new GridPane();
		gp.setVgap(15);
		gp.setHgap(15);
		gp.setPadding(new Insets(10));
		 
		TextArea t = new TextArea(); //TextArea to display what we want 
		Button clearBT = new Button("Refresh");
		HBox txtAreaHB = new HBox();
		txtAreaHB.setSpacing(15);
		txtAreaHB.getChildren().addAll(t,clearBT);
		gp.add(txtAreaHB, 0, 2);
  
		RadioButton westBankRB = new RadioButton("West Bank");
		westBankRB.setOnAction(e->{ //Action to display West Bank list
			t.setText(westBankList.toString());
		});
		
		RadioButton gazaRB = new RadioButton("Gaza");
		gazaRB.setOnAction(e->{ //Action to display Gaza list
			t.setText(gazaList.toString());
		});
		//put the Radio Buttons in ToggleGroup 
		ToggleGroup regionTG = new ToggleGroup();
		westBankRB.setToggleGroup(regionTG);
		gazaRB.setToggleGroup(regionTG);
		
		Label selectLB = new Label("Select :");
		
		HBox selectHB = new HBox();
		selectHB.setSpacing(10);
		selectHB.getChildren().addAll(selectLB,westBankRB,gazaRB);
		gp.add(selectHB, 0, 0);
		
		Button scientificBT = new Button("Scientific");
		scientificBT.setOnAction(e->{ //Action to display Scientific branch of lists
			if(westBankRB.isSelected()) {
				t.setText(westBankList.scientificPrint());
			}
			else {
				t.setText(gazaList.scientificPrint());
			}
		});
		
		Button literaryBT = new Button("Literary");
		literaryBT.setOnAction(e->{ //Action to display Literary branch of lists
			if(westBankRB.isSelected()) {
				t.setText(westBankList.LiteraryPrint());
			}
			else {
				t.setText(gazaList.LiteraryPrint());
			}
		});
		
		HBox select2HB = new HBox();
		selectHB.setSpacing(10);
		selectHB.getChildren().addAll(scientificBT,literaryBT);
		gp.add(select2HB, 0, 1);
		
		Label insertLB = new Label ("To insert new Student : ");
		gp.add(insertLB, 0, 3);
		
		Label seatLB = new Label ("Enter Seat Number : ");
		TextField seatNumTF = new TextField();
		Button insertBT = new Button("Insert Student");
		HBox isnertSeatNumHB = new HBox();
		isnertSeatNumHB.setSpacing(33);
		isnertSeatNumHB.getChildren().addAll(seatLB,seatNumTF);
		gp.add(isnertSeatNumHB, 0, 4);
		
		Label branchLB = new Label ("Enter student's branch : ");
		TextField branchTF = new TextField();
		HBox isnertbranchHB = new HBox();
		isnertbranchHB.setSpacing(15);
		isnertbranchHB.getChildren().addAll(branchLB,branchTF);
		gp.add(isnertbranchHB, 0, 5);
		
		Label avgLB = new Label ("Enter student's average : ");
		TextField avgTF = new TextField();
		HBox isnertavgHB = new HBox();
		isnertavgHB.setSpacing(9);
		isnertavgHB.getChildren().addAll(avgLB,avgTF,insertBT);
		gp.add(isnertavgHB, 0, 6);
		
		insertBT.setOnAction(e->{ //Action to insert new students in the lists
			if(westBankRB.isSelected()) {
				seatNumber=Integer.parseInt(seatNumTF.getText());
				branch=branchTF.getText();
				avg=Double.parseDouble(avgTF.getText());
				westBankList.insertSorted(seatNumber, branch, avg);
			}
			else if(gazaRB.isSelected()) {
				seatNumber=Integer.parseInt(seatNumTF.getText());
				branch=branchTF.getText();
				avg=Double.parseDouble(avgTF.getText());
				gazaList.insertSorted(seatNumber, branch, avg);
			}
		
		});
		
		Label deleteAndSearchLB = new Label ("To delete record or Search for it just fill the Seat number:");
		TextField dAndSSNumTF = new TextField(); 
		Button deleteBT = new Button("Delete Record");
		Button searchBT = new Button("Search for Record");
		
		HBox searchDeleteHb = new HBox();
		searchDeleteHb.setSpacing(10);
		searchDeleteHb.getChildren().addAll(deleteAndSearchLB,dAndSSNumTF,deleteBT,searchBT);
		gp.add(searchDeleteHb, 0, 7);
		
		deleteBT.setOnAction(e->{ //Action to delete students from the lists
			seatNumber=Integer.parseInt(dAndSSNumTF.getText());
			if(westBankRB.isSelected()) {
				westBankList.delete(seatNumber);
				t.setText("The record has deleted");
			}
			else if(gazaRB.isSelected()) {
				gazaList.delete(seatNumber);
				t.setText("The record has deleted");
			}
			else {
				t.setText("There is no record to delete");
			}
		});
		
		searchBT.setOnAction(e->{ //Action to search about students in the lists
			seatNumber=Integer.parseInt(dAndSSNumTF.getText());
			if(westBankRB.isSelected()) {
				t.setText(westBankList.search(seatNumber));
			}
			else if(gazaRB.isSelected()) {
				t.setText(gazaList.search(seatNumber));
			}
		});
		
		Label otherLB = new Label ("Other choices :");
		gp.add(otherLB, 0, 8);
		
		Label topTenLB = new Label ("Display the top Student According to the grade :");
		Button topTenBT = new Button("Top 10");
		HBox topTenHB = new HBox();
		topTenHB.setSpacing(10);
		topTenHB.getChildren().addAll(topTenLB,topTenBT);
		gp.add(topTenHB,0 ,9 );
		
		topTenBT.setOnAction(e->{ //Action to display Top 10 students in the lists
			if(westBankRB.isSelected()) {
				t.setText(westBankList.topTen());
				
			}
			if(gazaRB.isSelected()) {
				t.setText(gazaList.topTen());
			}
		});
		
		
		Label meanLB = new Label ("Display Mean or Mode :");
		Button meanBT = new Button("mean");
		Button modeBT = new Button("mode");
		HBox meanHB = new HBox();
		meanHB.setSpacing(10);
		meanHB.getChildren().addAll(meanLB,meanBT,modeBT);
		gp.add(meanHB,0 ,10 );
		
		meanBT.setOnAction(e->{ //Action to display the mean of the lists
			if(westBankRB.isSelected()) {
				t.setText(westBankList.mean());
				
			}
			if(gazaRB.isSelected()) {
				t.setText(gazaList.mean());
			}
		});
		
		modeBT.setOnAction(e->{ //Action to display the mode of the lists
			if(westBankRB.isSelected()) {
				t.setText(westBankList.mode());
			}
			if(gazaRB.isSelected()) {
				t.setText(gazaList.mode());
			}
		});
		
		Label nAndPLB = new Label ("Enter a specific grade to Display The number and % of Student"
				+ " whom above or equal to it : ");
		TextField nAndPTF = new TextField();
		Button nAndPBT = new Button("Number And Percentage");
		HBox nAndPHB = new HBox();
		nAndPHB.setSpacing(10);
		nAndPHB.getChildren().addAll(nAndPLB,nAndPTF);
		gp.add(nAndPHB,0 ,11 );
		gp.add(nAndPBT, 0, 12);
		
		nAndPBT.setOnAction(e->{ /*Action to display the number and percentage of students
		 whom grade above or equal a specific grade of the lists */
			avg=Double.parseDouble(nAndPTF.getText()); 
			
			if(westBankRB.isSelected()) {
				t.setText(westBankList.numberAndPercentage(avg));
			}
			if(gazaRB.isSelected()) {
				t.setText(gazaList.numberAndPercentage(avg));
			}
		});
		
		clearBT.setOnAction(e->{ // Action to refresh the GUI 
			t.clear();
			seatNumTF.clear();
			branchTF.clear();
			avgTF.clear();
			dAndSSNumTF.clear();
			nAndPTF.clear();
		});
		
		//create scene and put it in the stage and show the stage
		Scene scene = new Scene(gp,750,700);
		primaryStage.setScene(scene);
		primaryStage.setTitle(" Tawjihi 2022 Records ");
		primaryStage.show();		
	
	}
	public static void main(String[] args) throws FileNotFoundException {

		//read from West Bank file 
		File f = new File("westBank.txt");
		if (f.exists()) {
			Scanner in = new Scanner(f);
			while (in.hasNext()) {
				String line = in.nextLine();
				String[] token = line.split(",");
				seatNumber = Integer.parseInt(token[0].trim());
				branch = token[1].trim();
				avg = Double.parseDouble(token[2].trim());
				westBankList.insertSorted(seatNumber, branch, avg);
			}
		}
		//read from Gaza file 
		File f2 = new File("gaza.txt");
		if (f2.exists()) {
			Scanner in = new Scanner(f2);
			while (in.hasNext()) {
				String line = in.nextLine();
				String[] token = line.split(",");
				seatNumber = Integer.parseInt(token[0].trim());
				branch = token[1].trim();
				avg = Double.parseDouble(token[2].trim());
				gazaList.insertSorted(seatNumber, branch, avg);
			}
		}
		launch(args);
	}
}
